Demo site for ATHENA TurboTax integration POC

How to use
1. Ensure the local ATHENA backend is running and accessible at the working host (e.g. http://localhost)
2. Serve the docs folder on a simple static server or open `docs/integration/demo/index.html` in a browser within the app environment so relative API calls reach the same host.

Quick example (PowerShell):

# Serve using Python's simple HTTP server
env:PSHOME
python -m http.server --directory docs/integration/demo 8000

Open http://localhost:8000 in your browser

Notes
- The demo calls the following endpoints relative to the current origin:
  - POST /api/v1/turbotax/oauth/start
  - POST /api/v1/turbotax/projection
- Ensure CORS and server are configured for your local environment.
